﻿namespace DGerald_CPT_A80S_CityList
{


    partial class CityDBDataSet
    {
    }
}

namespace DGerald_CPT_A80S_CityList.CityDBDataSetTableAdapters {
    
    
    public partial class CityTableAdapter {
    }
}
